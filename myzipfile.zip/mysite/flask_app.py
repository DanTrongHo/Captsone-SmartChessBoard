from flask import Flask, request, redirect, abort, render_template, session
import os.path
import os
#import atexit
import time



app = Flask(__name__, template_folder='/home/DanTrongHo/mysite/SmartChessBoardMain/venv/templates', static_folder="/home/DanTrongHo/mysite/SmartChessBoardMain/venv/static")

#readTarget = ""
instanceType = ""
gameID = ""
colorFileO = ""
colorFileT = ""
fileName = "/home/DanTrongHo/mysite/CorrespondenceFile"
mod_time0 = 0;
mod_time1 = 0;

@app.route("/clean", methods=["POST"])
def cleanupFiles(): # Clean up files created by the web app
    # Clean up color Check
    print("Cleaning")
    if os.path.exists(colorFileO):
        os.remove(colorFileO)
    if os.path.exists(colorFileT):
        os.remove(colorFileT)
    if os.path.exists(fileName+gameID+"O.txt"):
        os.remove(fileName+gameID+"O.txt")
    if os.path.exists(fileName+gameID+"T.txt"):
        os.remove(fileName+gameID+"T.txt")

# Need to determine who is what color, best way to do this is check to see who gets on first, they get to pick and second has to switch
def colorCheck(colorType, gameID, appType):
    global colorFileO
    global colorFileT

    otherType = ""
    if appType == "O":
        otherType = "T"
    else:
        otherType = "O"

    colorFileName = "/home/DanTrongHo/mysite/" + colorType + otherType + gameID + ".txt"
    ownFileName = "/home/DanTrongHo/mysite/" + colorType + appType + gameID + ".txt"

    if appType == "O":
        colorFileO = ownFileName
    else:
        colorFileT = ownFileName

    if os.path.exists(colorFileName):
        if colorType == "white":
            return("black")
        else:
            return("white")
    else:
        f = open(ownFileName, 'w+')
        f.write(" ")
        f.close()
        return(colorType)


# Check that the opposing file exists
# then just write, otherwise need to create the file
def writeValue(sourceReceived, targetReceived, gameidReceived, appType):
    global mod_time0
    global mod_time1
    global gameID
    global instanceType
    #global readTarget
    print("Writing")

    idFileName = ''
    idFileNameSignature = ''
    print("Write 1")
    if appType == "O": # get the opposing CF
        idFileName = fileName + gameidReceived + "T" + ".txt"
        idFileNameSignature = fileName + gameidReceived + "O" + ".txt"
    else:
        idFileName = fileName + gameidReceived + "O" + ".txt"
        idFileNameSignature = fileName + gameidReceived + "T" + ".txt"
    print("Write 2")
    if os.path.isfile(idFileName) or os.path.isfile(idFileNameSignature):   # Open oppposing CF, write values then wait
         f = open(idFileName, 'w')
         f.write(sourceReceived + "-" + targetReceived)
         f.close()
         os.rename(idFileName, idFileNameSignature)
    else: # First player
        f = open(idFileNameSignature, 'w')
        f.write(sourceReceived + "-" + targetReceived)
        f.close()
        readTarget = idFileNameSignature

    print("Write 3")
    #Wait(idFileName)
    return ("OK")

def readValue(gameID, appType): #ReadCF and return the move data found within
    print("Reading")
    readTarget = ""
    otherType = ""
    if appType == "O":
        otherType = "T"
    else:
        otherType = "O"

    readTarget = "/home/DanTrongHo/mysite/CorrespondenceFile" + gameID + otherType + ".txt"
    print(readTarget)
    if os.path.exists(readTarget):
        try:
            os.rename(readTarget, readTarget)
            with open(readTarget, 'r') as f:
                returnPackage = f.read()
                f.close()
                print(returnPackage)
                return(returnPackage)
        except:
            print("Waiting1")
            return("IU")
    else:
        print("Waiting2")
        return("IU")

# Main function call that handles ajax requests and initial start up
@app.route("/", methods=["GET", "POST"])
def home():
    requestType = ""
    global gameID
    if request.method == "POST":
        requestType = request.form["requestType"]
        gameID = request.form["gameidData"]

        if requestType == "color": #Get the corresponding variables and pass to the color function
            type = request.form["appType"]
            color = request.form["colorType"]
            gameid = request.form["gameidData"]
            return(colorCheck(color, gameid, type))
        elif requestType == "write":
            print("Starting Write")
            print(request.form)
            sourceReceived = request.form["sourceData"]
            targetReceived = request.form["targetData"]
            gameidReceived = request.form["gameidData"]
            appType = request.form["appType"]
            return(writeValue(sourceReceived, targetReceived, gameidReceived, appType))
        elif requestType == "read":
            gameidReceived = request.form["gameidData"]
            appType = request.form["appType"]
            return(readValue(gameidReceived, appType))


    # Execute below if request type is empty
    play_Method = request.args.get("playMethod")
    if (play_Method == "online"):
        return render_template("ChessBoardOnlineNew.html")
    elif (play_Method == "traditional"):
        return render_template("ChessBoardTraditionalNew.html")

    return render_template('ChessBoardMenu.html')




def Wait(targetFileName): # This one is used after a write
    print("Waiting!First")
    while not os.path.exists(targetFileName): #Wait for file name to appear
        time.sleep(5)
    if os.path.isfile(targetFileName): #Read File Name
        print("Done Waiting!First")
        #read(targetFileName)


#@app.route("/read", methods=["GET", "POST"])
#def read(): #ReadCF and return the move data found within
#    print("Reading")
#
#    if (request.method == "POST"):
#        if os.path.exists(readTarget):
#            try:
#                os.rename(readTarget, readTarget)
#                with open(readTarget, 'r') as f:
#                    returnPackage = f.read()
#                    f.close()
#                    print(returnPackage)
#                    return(returnPackage)
#            except:
#                print("Waiting1")
#                return("IU")
#        else:
#            print("Waiting2")
#            return("IU")


if __name__ == '__main__':
    app.debug = True
    app.run()