from flask import Flask, request, redirect, abort, render_template, session
import os.path
import os

import time



app = Flask(__name__, template_folder='/home/DanTrongHo/mysite/SmartChessBoardMain/venv/templates', static_folder="/home/DanTrongHo/mysite/SmartChessBoardMain/venv/static")

readTarget = ""
instanceType = ""
gameID = ""
fileName = "/home/DanTrongHo/mysite/CorrespondenceFile"
mod_time0 = 0;
mod_time1 = 0;





@app.route("/")
def home():
    play_Method = request.args.get("playMethod")
    if (play_Method == "online"):
        return render_template("ChessBoardOnline.html")
    elif (play_Method == "traditional"):
        return render_template("ChessBoardTraditional.html")

    return render_template('ChessBoardMenu.html')


@app.route("/color", methods=["GET", "POST"])
def color():
    print("Color Function Start")
    if request.method == "POST":
        type = request.form["type"]
        color = request.form["color"]
        gameid = request.form["gameID"]
    if type == "O":
        otherType = "T"
    else:
        otherType = "O"
    colorFileName =   "/home/DanTrongHo/mysite/" + color + otherType + gameid + ".txt"
    if os.path.exists(colorFileName): #Color already exists, so you are now other color
        if color == "white":
            return("black")
        else:
            return("white")
    else:
        print("Color Test")
        f = open(colorFileName, 'r')
        f.close()
        return(color)


@app.route("/wait", methods=["POST"])
def wait(): # Used only for initial wait
    global gameID
    global instanceType
    global readTarget
    if request.method == "POST":
        type = request.form["type"]
        instanceType = type
        gameID = request.form["gameidData"]
    if type == "O":
        targetFileName = fileName + gameID + "T" + ".txt"
    else:
        targetFileName = fileName + gameID + "O" + ".txt"
    readTarget = targetFileName

    print("WaitingFirst")
    print(targetFileName)
    while not os.path.exists(targetFileName): #Wait for file name to appear
        time.sleep(5)
    if os.path.isfile(targetFileName): #Read File Name
        print("Done WaitingFirst")
        return


#    global mod_time0
#    global mod_time1
#    new_mtime = time.ctime(os.path.getmtime(fileName))
#    print("Waiting")
#    print(new_mtime)
#    idFileName = fileName + gameID + ".txt"
#    type = ""
#    if request.method == "POST":
#        type = request.form["type"]
#    while True:
#        new_mtime = time.ctime(os.path.getmtime(fileName))
#        if os.path.exists(fileName):
#           if type == "O":
#               if new_mtime != mod_time0:
#                    return("done")
#            else:
#                if new_mtime != mod_time1:
#                    return("done")
            #try:
            #    p = open(fileName, "r")
            #    p.close()
            #    #os.rename(fileName, fileName)
            #    with open(fileName) as f:
            #        if f.read()[0] == type or f.read()[0] == "": #Either empty or opposing player hasn't written
            #            time.sleep(2)
            #            print("Checking")
            #        else:
            #            print("Written")
            #            return("OK")
            #except Exception:
            #    pass

@app.route("/write", methods=["GET", "POST"])
def write():
    global mod_time0
    global mod_time1
    global gameID
    global instanceType
    global readTarget
    print("Writing")
    if (request.method == "POST"):
        sourceReceived = request.form['sourceData']
        targetReceived = request.form['targetData']
        gameidReceived = request.form['gameidData']
        type = request.form['type']
        instanceType = type
        print(sourceReceived) #Here is where you would write to file the online signature with move, as well as start checking for response
        print(targetReceived)
        print(gameidReceived)
        gameID = gameidReceived
        idFileName = ''
        idFileNameSignature = ''

        if type == "O": # get the opposing CF
            idFileName = fileName + gameidReceived + "T" + ".txt"
            idFileNameSignature = fileName + gameidReceived + "O" + ".txt"
        else:
            idFileName = fileName + gameidReceived + "O" + ".txt"
            idFileNameSignature = fileName + gameidReceived + "T" + ".txt"

        if os.path.isfile(idFileName) or os.path.isfile(idFileNameSignature):   # Open oppposing CF, write values then wait
             f = open(idFileName, 'w')
             f.write(sourceReceived + "-" + targetReceived)
             f.close()
             os.rename(idFileName, idFileNameSignature)
        else: # First player
            f = open(idFileNameSignature, 'w')
            f.write(sourceReceived + "-" + targetReceived)
            f.close()
            readTarget = idFileNameSignature

    #   while True:
    #        try:
    #            with open(idFileName, 'w') as f:
    #                f.write(type + sourceReceived + "-" + targetReceived)
    #                if type == "O":
    #                    mod_time0 = time.ctime(os.path.getmtime(idFileName))
    #                    print(mod_time0)
    #                else:
    #                    mod_time1 = time.ctime(os.path.getmtime(idFileName))
    #                    print(mod_time1)
    #                return("ok")
    #        except Exception:
    #            pass
    #Wait(idFileName)
    return ("OK")


def Wait(targetFileName): # This one is used after a write
    print("Waiting!First")
    while not os.path.exists(targetFileName): #Wait for file name to appear
        time.sleep(5)
    if os.path.isfile(targetFileName): #Read File Name
        print("Done Waiting!First")
        read(targetFileName)


@app.route("/read", methods=["GET", "POST"])
def read(): #ReadCF and return the move data found within
    print("Reading")
    if (request.method == "POST"):
        if os.path.exists(readTarget):
            try:
                os.rename(readTarget, readTarget)
                with open(readTarget, 'r') as f:
                    returnPackage = f.read()
                    f.close()
                    print(returnPackage)
                    return(returnPackage)
            except:
                print("Waiting1")
                return("IU")
        else:
            print("Waiting2")
            return("IU")


if __name__ == '__main__':
    app.debug = True
    app.run()